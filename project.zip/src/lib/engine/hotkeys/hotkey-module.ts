import { OneToManyDictionary } from '$lib/engine/patterns/one-to-many-dictionary';
import { HotKey } from './hotkey-class';

type EventHandler<E extends Event> = (event: E) => void;

class HotkeysModule {
	#wasInitialized = false;

	#hotKeysHandlers = new OneToManyDictionary<HotKey, EventHandler<KeyboardEvent>>(true);
	#hotKeysCaptureHandlers = new OneToManyDictionary<HotKey, EventHandler<KeyboardEvent>>(true);

	#onKeydownBound: (event: KeyboardEvent) => void = this.#onKeydown.bind(this);

	assignHotKey(key: HotKey, handler: EventHandler<KeyboardEvent>, isCaptrue = false) {
		console.debug('HotkeysModule assigning key:', key, 'to handler:', handler.toString());

		if (!this.#wasInitialized) {
			throw new Error(`${HotkeysModule.name} Need to initialize Class before assigning hotkeys`);
		}

		if (isCaptrue) {
			this.#hotKeysCaptureHandlers.add(key, handler);
		} else {
			this.#hotKeysHandlers.add(key, handler);
		}
	}

	removeHotKey(key: HotKey, handler: EventHandler<KeyboardEvent>) {
		this.#hotKeysHandlers.remove(key, handler);
		this.#hotKeysCaptureHandlers.remove(key, handler);
	}

	assignHotKeys(keys: HotKey[], handler: EventHandler<KeyboardEvent>, isCaptrue = false) {
		keys.forEach((key) => this.assignHotKey(key, handler, isCaptrue));
	}

	removeHotKeys(keys: HotKey[], handler: EventHandler<KeyboardEvent>) {
		keys.forEach((key) => this.removeHotKey(key, handler));
	}

	count = 0;
	#onKeydown(event: KeyboardEvent) {
		let hotKeyedHandlers = this.#hotKeysHandlers;

		if (event.eventPhase === Event.CAPTURING_PHASE) {
			hotKeyedHandlers = this.#hotKeysCaptureHandlers;
		}

		let eventKey = HotKey.fromEvent(event);
		const possibleMatches = eventKey.getPossibleRegisteredMatches();

		const matches = hotKeyedHandlers.getMultiple(possibleMatches);

		const handlers = eventKey.pickBestMatch(
			matches.map(({ key, values }) => ({
				hotKey: key,
				cbObject: values
			}))
		);

		console.debug('HotkeysModule - reachedKeydownEvent key:', eventKey.toKey(), 'relevantHandlers', handlers?.length);

		// Fires Last Handler - Hopefully this is good enough for most cases.
		handlers?.at(-1)?.(event);
	}

	init() {
		if (this.#wasInitialized) {
			throw new Error(`${HotkeysModule.name} Was already initialized`);
		}

		document.addEventListener('keydown', this.#onKeydownBound);
		document.addEventListener('keydown', this.#onKeydownBound, { capture: true });
		this.#wasInitialized = true;
	}

	destroy() {
		document.removeEventListener('keydown', this.#onKeydownBound);
		document.removeEventListener('keydown', this.#onKeydownBound, { capture: true });

		this.#hotKeysHandlers = new OneToManyDictionary();
		this.#wasInitialized = false;
	}
}

export const hotKeysModule = new HotkeysModule();
