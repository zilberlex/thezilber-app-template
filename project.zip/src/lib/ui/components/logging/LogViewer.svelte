<script lang="ts">
	import { composeTransitions } from '$lib/engine/transitions/transition-tools/transition-composition/compose-transitions';
	import { typewriter } from '$lib/engine/transitions/typewriter';
	import { cubicOut, linear } from 'svelte/easing';
	import { fade, slide } from 'svelte/transition';
	type LogSeverity = 'debug' | 'info' | 'warn' | 'error';
	type LogContext = Record<string, unknown> & { scope: string };
	type LogLine = {
		severity: LogSeverity;
		message: string;
		context: LogContext;
	};

	export interface EngineLogger {
		log: (message: string, context: LogContext) => void;
		debug: (message: string, context: LogContext) => void;
		warn: (message: string, context: LogContext) => void;
		error: (message: string, context: LogContext) => void;
	}

	let { logger = $bindable() }: { logger?: EngineLogger } = $props();

	const logs = $state(new Array<LogLine>());

	const logInternal = (severity: LogSeverity, message: string, context: LogContext) => {
		logs.push({
			severity,
			message,
			context
		});

		console[severity](message, context);
	};

	logger = {
		log: (message: string, context: LogContext) => {
			logInternal('info', message, context);
		},
		debug: (message: string, context: LogContext) => {
			logInternal('debug', message, context);
		},
		warn: (message: string, context: LogContext) => {
			logInternal('warn', message, context);
		},
		error: (message: string, context: LogContext) => {
			logInternal('error', message, context);
		}
	};

	const composedTransition = composeTransitions([
		{
			transition: slide,
			params: {
				delay: 0,
				duration: 300,
				axis: 'y',
				easing: cubicOut
			}
		},
		{
			transition: fade,
			params: {
				delay: 0,
				easing: cubicOut,
				duration: 300
			}
		},
		{
			transition: typewriter,
			params: {
				easing: linear,
				delay: 50,
				speed: 4
			}
		}
	]);
</script>

<div class="log-viewer">
	{#each logs as logLine}
		<div class={['log-line', 'box', logLine.severity]} transition:composedTransition>
			<span class="log-line-scope"><em>[</em>{logLine.context.scope}<em>]</em>:</span>
			{logLine.message}
		</div>
	{/each}
</div>

<style>
	.log-viewer {
		min-height: 100%;
		display: flex;
		flex-direction: column;
		justify-content: flex-end;
		gap: var(--space-2);

		.log-line {
			border-radius: var(--shape-element-radius);
			clip-path: (--shape-element-clip);
			mask: var(--shape-element-mask);

			font-style: italic;

			.log-line-scope {
				font-weight: 600;
				&,
				& * {
					font-style: normal !important;
				}
			}
		}

		& .error {
			border-color: var(--cl-error);
			& em {
				color: var(--cl-error);
			}
		}
	}
</style>
